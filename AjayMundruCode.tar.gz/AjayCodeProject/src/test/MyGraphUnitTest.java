package test;

import static org.junit.Assert.*;

import java.util.stream.Collectors;

import org.junit.Test;

import myGraph.GNode;
import myGraph.GraphTraversal;

public class MyGraphUnitTest {

	@Test
	public void nodesInGraphTest() {
		String expectedOutput = "A, B, E, F, C, G, H, I, D, J";
		String actualOutput;
		GraphTraversal.createGraph();
		//Invoking walkGraph method in GraphTraversal
		actualOutput = GraphTraversal.walkGraph(GraphTraversal.getA()).stream().map(GNode::getName).collect(Collectors.joining(", "));
		assertEquals(actualOutput, expectedOutput);
	}
	
	@Test
	public void pathsInGraphTest() {
		String expectedOutput = "(A, B, E) (A, B, F) (A, C, G) (A, C, H) (A, C, I) (A, D, J)";
		String actualOutput;
		StringBuilder sb = new StringBuilder();
		GraphTraversal.createGraph();
		//Invoking paths method in GraphTraversal
		GraphTraversal.paths(GraphTraversal.getA()).stream().forEach((gnodes) -> 
		{ 
			sb.append("(");
			sb.append(gnodes.stream().map(GNode::getName).collect(Collectors.joining(", ")));
			sb.append(") ");
		});
		actualOutput = sb.toString().trim();
		assertEquals(actualOutput, expectedOutput);
	}

}
