package myWordCount;

import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;

public class WordCount {

	public static void main(String[] args) {
		Map<String, Integer> wordCount = new TreeMap<>();
		//Pattern for word
		Pattern wordPattern = Pattern.compile("\\w+", Pattern.CASE_INSENSITIVE);
		BufferedReader bufferReader = null;

		try {
			 //Create object of FileReader
	          FileReader inputFile = new FileReader("text.txt"); //file located at classpath

	          //Instantiate the BufferedReader Class
	          bufferReader = new BufferedReader(inputFile);
	          
	          String line;
	          
	          while ((line = bufferReader.readLine()) != null) {
				Matcher wordMatch = wordPattern.matcher(line);
				while (wordMatch != null && wordMatch.find()) {
					String word = wordMatch.group().toLowerCase();
					int count = wordCount.getOrDefault(word, 0);
					wordCount.put(word, count + 1);
				}
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally{
			try {
				bufferReader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

		for (Entry<String, Integer> e : wordCount.entrySet()) {
			System.out.println(e.getKey() + " " + e.getValue());
		}
	}
}