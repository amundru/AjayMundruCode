package myGraph;

import java.util.Arrays;

public class GNodeImpl implements GNode{
	
	String name;
	GNode[] children;
	
	public GNodeImpl(String name, GNode[] children) {
		super();
		this.name = name;
		this.children = children;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public GNode[] getChildren() {
		return children;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setChildren(GNode[] children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return "GNodeImpl [name=" + name + ", children=" + Arrays.toString(children) + "]";
	}
}
