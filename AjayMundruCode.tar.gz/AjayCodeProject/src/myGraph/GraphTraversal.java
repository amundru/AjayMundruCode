package myGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GraphTraversal {
	//Represents nodes in the graph.
	static List<GNode> gnodes = new ArrayList<>();
	//Represents nodes in a path from a given node to leaf node of the graph.
	static List<GNode> nodesInPathList = new ArrayList<>();
	//Represents list of all possible paths through the graph from a given node.
	static List<List<GNode>> totalPathsList = new ArrayList<>();
	//Map to maintain visited flag value for each node in the graph while traversing it.
	static Map<String, Boolean> visitedInfoMap;
	//Nodes in the graph.
	static GNode a;
	static GNode b;
	static GNode c;
	static GNode d;
	static GNode e;
	static GNode f;
	static GNode g;
	static GNode h;
	static GNode i;
	static GNode j;

	public static void main(String[] args) {
        
		// Directed acyclic graph creation.
		createGraph();
		
		// Traversing the graph from a node to visit all nodes in the graph.
		walkGraph(a);
		System.out.println("List of nodes in the graph : ");
		System.out.println(gnodes.stream().map(GNode::getName).collect(Collectors.joining(", ")));
		
		// Setting visited flag value to false
		setVisitedInfoMap();
        
		// Getting all possible paths through the graph starting at a node.
		paths(a);
		System.out.println("Total paths in the graph from node : " + a.getName());
		totalPathsList.stream().forEach((gnodes) -> 
		{ 
			System.out.print("(");
			System.out.print(gnodes.stream().map(GNode::getName).collect(Collectors.joining(", ")));
			System.out.print(") ");
		});
	}
	
	// Directed acyclic graph creation.
	public static void createGraph() {
		j = new GNodeImpl("J", new GNode[] {});
		g = new GNodeImpl("G", new GNode[] {});
		h = new GNodeImpl("H", new GNode[] {});
		i = new GNodeImpl("I", new GNode[] {});
		e = new GNodeImpl("E", new GNode[] {});
		f = new GNodeImpl("F", new GNode[] {});
		b = new GNodeImpl("B", new GNode[] { e, f });
		c = new GNodeImpl("C", new GNode[] { g, h, i });
		d = new GNodeImpl("D", new GNode[] { j });
		setA(new GNodeImpl("A", new GNode[] { b, c, d }));
        
		// Map to store the visited flag value for each node.
		visitedInfoMap = new HashMap<String, Boolean>();
		
		// Setting visited flag value to false for all nodes initially.
		setVisitedInfoMap();
	}

	private static void setVisitedInfoMap() {
		visitedInfoMap.put(a.getName(), false);
		visitedInfoMap.put(b.getName(), false);
		visitedInfoMap.put(c.getName(), false);
		visitedInfoMap.put(d.getName(), false);
		visitedInfoMap.put(e.getName(), false);
		visitedInfoMap.put(f.getName(), false);
		visitedInfoMap.put(g.getName(), false);
		visitedInfoMap.put(h.getName(), false);
		visitedInfoMap.put(i.getName(), false);
		visitedInfoMap.put(j.getName(), false);
	}
 
	public static List<GNode> walkGraph(GNode gnode) {
		gnodes.add(gnode);
		visitedInfoMap.put(gnode.getName(), true);

		if (gnode.getChildren().length == 0) {
			return gnodes;
		}
		for (GNode childNode : gnode.getChildren()) {
			if(visitedInfoMap.get(childNode.getName()) == false){
				walkGraph(childNode);
			}	
		}
		return gnodes;
	}
	
	public static List<List<GNode>> paths(GNode gnode) {
		nodesInPathList.add(gnode);
		visitedInfoMap.put(gnode.getName(), true);
		if (gnode.getChildren().length == 0) {
			List<GNode> tempList = new ArrayList<GNode>();
			tempList.addAll(nodesInPathList);
			totalPathsList.add(tempList);
			return totalPathsList;
		}

		for (GNode childNode : gnode.getChildren()) {
			if(visitedInfoMap.get(childNode.getName()) == false){
				paths(childNode);
				nodesInPathList.remove(nodesInPathList.size() - 1);
			}	
		}
		return totalPathsList;
	}
    
	//useful to get node object in MyGraphUnitTest.
	public static GNode getA() {
		return a;
	}

	public static void setA(GNode a) {
		GraphTraversal.a = a;
	}

	public static GNode getB() {
		return b;
	}

	public static GNode getC() {
		return c;
	}

	public static GNode getD() {
		return d;
	}

	public static GNode getE() {
		return e;
	}

	public static GNode getF() {
		return f;
	}

	public static GNode getG() {
		return g;
	}

	public static GNode getH() {
		return h;
	}

	public static GNode getI() {
		return i;
	}

	public static GNode getJ() {
		return j;
	}
}
