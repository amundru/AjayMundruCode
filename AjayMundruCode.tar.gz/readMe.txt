My Assumptions :
Graph defined by a GNode is acyclic (no cycles), directed and I implemented it for an unconnected graph.

 
'AjayCodeProject' project Structure:

myGraph package contains
1. GNode - Interface 
2. GNodeImpl - Class that implements GNode interface
3. GraphTraversal - Class that has the solution for 1(walkGraph method) & 2(paths method) questions.


myWordCount package contains
WordCount - Class that has the solution for 3rd question. It just prints word count for each word in the "text.txt" file 
(located in the project classpath) to the console.

test package contains 
MyGraphUnitTest - Class that has unit test cases for questions 1 and 2.


JUnit JAR is also provided to you to add it to class path to run the test cases, incase if you do not have it.

Java Version : 1.8


Thanks,
Ajay Mundru.
